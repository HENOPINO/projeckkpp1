/* =========================================
   Departemen Support Tambang Batubara
   PT KPP — Interaksi halaman
   ========================================= */
(function () {
  'use strict';

  /* ---------- 1. Data SOP (GANTI dengan data asli) ---------- */
  var SOPS = [
    {
      no: 'SOP-OB-001',
      title: 'Pelaksanaan stripping Overburden',
      category: 'Overburden',
      desc: 'Tahapan pekerjaan overburden: stripping, doze, backfill, dan level benches sesuai target SR per blok.',
      revisi: '03',
      tanggal: '12 Jan 2026',
      file: 'docs/SOP-OB-001-Stripping-Overburden.pdf'
    },
    {
      no: 'SOP-OB-004',
      title: 'Penanganan material ke stockpile',
      category: 'Overburden',
      desc: 'Prosedur stockpiling material overburden, penentuan zona stockpile, serta standar kepadatan compact.',
      revisi: '02',
      tanggal: '04 Feb 2026',
      file: 'docs/SOP-OB-004-Penanganan-Material.pdf'
    },
    {
      no: 'SOP-PRD-002',
      title: 'Pengeboran dan pengambilan sampel',
      category: 'Produksi',
      desc: 'Pengeboran, pengambilan sampel batubara, pencatatan chainage, dan pengujian parameter kualitas sesuai standar.',
      revisi: '05',
      tanggal: '20 Feb 2026',
      file: 'docs/SOP-PRD-002-Pengeboran-Sampel.pdf'
    },
    {
      no: 'SOP-PRD-006',
      title: 'Pengangkutan batubara ke belt conveyor',
      category: 'Produksi',
      desc: 'Alur proses loading, feeding, dan penanganan masalah di stockpile menuju belt conveyor utama.',
      revisi: '01',
      tanggal: '02 Mar 2026',
      file: 'docs/SOP-PRD-006-Loading-Belt-Conveyor.pdf'
    },
    {
      no: 'SOP-K3-001',
      title: 'Keselamatan kerja di area tambang',
      category: 'K3',
      desc: 'Persyaratan K3 umum, PPE, izin kerja, dan prosedur tanggap darurat sebelum memulai aktivitas lapangan.',
      revisi: '07',
      tanggal: '18 Mar 2026',
      file: 'docs/SOP-K3-001-Keselamatan-Kerja.pdf'
    },
    {
      no: 'SOP-K3-005',
      title: 'Pelaksanaan toolbox meeting',
      category: 'K3',
      desc: 'Format, jadwal, dan materi toolbox meeting harian seluruh unit sebelum entering area kerja.',
      revisi: '02',
      tanggal: '25 Mar 2026',
      file: 'docs/SOP-K3-005-Toolbox-Meeting.pdf'
    },
    {
      no: 'SOP-MT-003',
      title: 'Preventive maintenance alat berat',
      category: 'Alat Berat',
      desc: 'Jadwal dan checklist perawatan berkala bulldozer, excavator, grader, dan dump truck.',
      revisi: '04',
      tanggal: '08 Apr 2026',
      file: 'docs/SOP-MT-003-Preventive-Maintenance.pdf'
    },
    {
      no: 'SOP-MT-008',
      title: 'Penanganan kerusakan alat di lapangan',
      category: 'Alat Berat',
      desc: 'Prosedur penanganan ringan di lapangan, pelaporan, dan pemanggilan tim workshop jika diperlukan.',
      revisi: '01',
      tanggal: '15 Apr 2026',
      file: 'docs/SOP-MT-008-Troubleshooting-Alat.pdf'
    }
  ];

  var DL_ICON =
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m0 0l-4.5-4.5M12 15l4.5-4.5M4 19h16" ' +
    'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  /* ---------- 2. Navbar: state sticky ---------- */
  var navbar = document.getElementById('navbar');

  function onScroll() {
    if (navbar) navbar.classList.toggle('is-stuck', window.scrollY > 24);
  }

  /* ---------- 3. Navbar mobile ---------- */
  var navToggle = document.getElementById('navToggle');
  var navMenu = document.getElementById('navMenu');

  function closeMenu() {
    if (!navMenu || !navToggle) return;
    navMenu.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
    navToggle.setAttribute('aria-label', 'Buka menu navigasi');
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      var open = navMenu.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(open));
      navToggle.setAttribute('aria-label', open ? 'Tutup menu navigasi' : 'Buka menu navigasi');
    });

    navMenu.addEventListener('click', function (e) {
      if (e.target.closest('.nav-link')) closeMenu();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeMenu();
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 820) closeMenu();
    });
  }

  /* ---------- 4. Smooth scroll dengan offset navbar ---------- */
  document.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      var id = link.getAttribute('href');
      if (!id || id === '#') return;
      var target = document.querySelector(id);
      if (!target) return;

      e.preventDefault();
      var navH = navbar ? navbar.offsetHeight : 0;
      var top = target.getBoundingClientRect().top + window.scrollY - navH - 12;
      window.scrollTo({ top: top < 0 ? 0 : top, behavior: 'smooth' });
      history.replaceState(null, '', id);
    });
  });

  /* ---------- 5. Scrollspy: highlight nav aktif ---------- */
  var navLinks = Array.prototype.slice.call(document.querySelectorAll('.nav-link'));
  var sections = navLinks
    .map(function (link) {
      var el = document.querySelector(link.getAttribute('href'));
      return el ? { el: el, link: link } : null;
    })
    .filter(Boolean);

  function spy() {
    var pos = window.scrollY + (navbar ? navbar.offsetHeight : 0) + 120;
    var current = sections.length ? sections[0].el : null;

    sections.forEach(function (s) {
      if (s.el.offsetTop <= pos) current = s.el;
    });

    // section terakhir: anggap aktif saat nearing bawah halaman
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 80 && sections.length) {
      current = sections[sections.length - 1].el;
    }

    navLinks.forEach(function (l) { l.classList.remove('is-active'); });
    if (current) {
      var match = sections.filter(function (s) { return s.el === current; })[0];
      if (match) match.link.classList.add('is-active');
    }
  }

  /* ---------- 6. Reveal on scroll ---------- */
  var revealTargets = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window) {
    var revealObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry, i) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        setTimeout(function () { el.classList.add('is-in'); }, Math.min(i * 70, 350));
        revealObs.unobserve(el);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

    revealTargets.forEach(function (el) { revealObs.observe(el); });
  } else {
    revealTargets.forEach(function (el) { el.classList.add('is-in'); });
  }

  /* ---------- 7. Counter angka statistik ---------- */
  function animateCount(el) {
    var target = parseFloat(el.dataset.count || '0');
    var decimals = parseInt(el.dataset.decimal || '0', 10);
    var suffix = el.dataset.suffix || '';
    var duration = 1500;
    var start = null;

    function fmt(n) {
      return n.toLocaleString('id-ID', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      }) + suffix;
    }

    function step(ts) {
      if (start === null) start = ts;
      var p = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(target * eased);
      if (p < 1) requestAnimationFrame(step);
      else el.textContent = fmt(target);
    }

    el.textContent = fmt(0);
    requestAnimationFrame(step);
  }

  var counters = Array.prototype.slice.call(document.querySelectorAll('[data-count]'));

  if ('IntersectionObserver' in window) {
    var countObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        animateCount(entry.target);
        countObs.unobserve(entry.target);
      });
    }, { threshold: 0.5 });
    counters.forEach(function (el) { countObs.observe(el); });
  } else {
    counters.forEach(function (el) { el.textContent = el.dataset.count + (el.dataset.suffix || ''); });
  }

  /* ---------- 8. Render kartu SOP ---------- */
  var grid = document.getElementById('sopGrid');
  var filtersWrap = document.getElementById('sopFilters');
  var searchInput = document.getElementById('sopSearch');
  var countLabel = document.getElementById('sopCount');
  var emptyState = document.getElementById('sopEmpty');

  var categories = ['Semua'];
  SOPS.forEach(function (s) {
    if (categories.indexOf(s.category) === -1) categories.push(s.category);
  });

  var activeCategory = 'Semua';

  function makeChip(label) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'chip' + (label === activeCategory ? ' is-active' : '');
    btn.textContent = label;
    btn.dataset.category = label;
    btn.addEventListener('click', function () {
      activeCategory = label;
      filtersWrap.querySelectorAll('.chip').forEach(function (c) {
        c.classList.toggle('is-active', c.dataset.category === label);
      });
      render();
    });
    return btn;
  }

  function makeCard(sop) {
    var card = document.createElement('article');
    card.className = 'sop-card reveal is-in';

    var head = document.createElement('div');
    head.className = 'sop-card__head';

    var no = document.createElement('span');
    no.className = 'sop-card__no';
    no.textContent = sop.no;

    var tag = document.createElement('span');
    tag.className = 'sop-card__tag';
    tag.textContent = sop.category;

    head.appendChild(no);
    head.appendChild(tag);

    var title = document.createElement('h3');
    title.textContent = sop.title;

    var desc = document.createElement('p');
    desc.className = 'sop-card__desc';
    desc.textContent = sop.desc;

    var foot = document.createElement('div');
    foot.className = 'sop-card__foot';

    var meta = document.createElement('span');
    meta.className = 'sop-card__meta';
    meta.textContent = 'Rev. ' + sop.revisi + ' \u00B7 ' + sop.tanggal;

    var dl = document.createElement('a');
    dl.className = 'sop-card__dl';
    dl.href = sop.file;
    dl.setAttribute('download', '');
    dl.setAttribute('aria-label', 'Unduh ' + sop.no + ' dalam format PDF');
    dl.innerHTML = DL_ICON;
    dl.appendChild(document.createTextNode('PDF'));

    foot.appendChild(meta);
    foot.appendChild(dl);

    card.appendChild(head);
    card.appendChild(title);
    card.appendChild(desc);
    card.appendChild(foot);

    return card;
  }

  function render() {
    if (!grid) return;

    var q = (searchInput ? searchInput.value : '').trim().toLowerCase();
    var list = SOPS.filter(function (s) {
      var byCat = activeCategory === 'Semua' || s.category === activeCategory;
      var byQuery = !q || (s.no + ' ' + s.title + ' ' + s.desc + ' ' + s.category)
        .toLowerCase()
        .indexOf(q) !== -1;
      return byCat && byQuery;
    });

    grid.innerHTML = '';
    list.forEach(function (sop) { grid.appendChild(makeCard(sop)); });

    if (countLabel) {
      countLabel.textContent = 'Menampilkan ' + list.length + ' dari ' + SOPS.length + ' dokumen SOP';
    }
    if (emptyState) emptyState.hidden = list.length !== 0;
  }

  if (filtersWrap) {
    categories.forEach(function (c) { filtersWrap.appendChild(makeChip(c)); });
  }
  if (searchInput) searchInput.addEventListener('input', render);
  render();

  /* ---------- 9. Back to top ---------- */
  var toTop = document.getElementById('toTop');

  if (toTop) {
    toTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  function toggleToTop() {
    if (toTop) toTop.classList.toggle('is-visible', window.scrollY > 600);
  }

  /* ---------- 10. Placeholder link (WA / Email) ---------- */
  document.querySelectorAll('a[data-placeholder]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      alert('Placeholder: ganti atribut href dengan link WhatsApp / email resmi PT KPP.');
    });
  });

  /* ---------- 11. Tahun footer ---------- */
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* ---------- 12. Init ---------- */
  var ticking = false;

  window.addEventListener('scroll', function () {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      onScroll();
      spy();
      toggleToTop();
      ticking = false;
    });
  }, { passive: true });

  onScroll();
  spy();
  toggleToTop();
})();
