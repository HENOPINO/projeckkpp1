const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
let errors = 0;
let warns = 0;

const ok = (m) => console.log('  OK   ' + m);
const err = (m) => { console.log('  FAIL ' + m); errors++; };
const warn = (m) => { console.log('  WARN ' + m); warns++; };

console.log('\n=== 1. Cek file referensi ===');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(ROOT, 'assets', 'js', 'main.js'), 'utf8');

const refs = [
  ...html.matchAll(/(?:href|src)="([^"#][^"]*)"/g),
].map((m) => m[1]).filter((r) => !/^(https?:|mailto:|tel:|data:)/.test(r));

const docRefs = [...js.matchAll(/file:\s*'([^']+)'/g)].map((m) => m[1]);

for (const ref of [...refs, ...docRefs]) {
  const target = path.join(ROOT, ref.replace(/\//g, path.sep));
  fs.existsSync(target) ? ok(ref) : err('MISSING: ' + ref);
}

console.log('\n=== 2. Cek PDF valid ===');
const pdfs = fs.readdirSync(path.join(ROOT, 'docs')).filter((f) => f.endsWith('.pdf'));
console.log('  jumlah PDF di docs/: ' + pdfs.length);
for (const f of pdfs) {
  const buf = fs.readFileSync(path.join(ROOT, 'docs', f));
  const header = buf.slice(0, 8).toString('latin1');
  const hasXref = buf.toString('latin1').includes('startxref');
  const hasEof = buf.toString('latin1').trimEnd().endsWith('%%EOF');
  if (header === '%PDF-1.4' && hasXref && hasEof) ok(f + ' (' + buf.length + ' bytes)');
  else err('PDF rusak: ' + f);
}

console.log('\n=== 3. Cek karakter non-ASCII tak lazim ===');
const ALLOWED = /[\x00-\x7F\u00B0\u00B1\u00D7\u00A0\u2013\u2014\u2018\u2019\u201C\u201D\u2026]/;
const files = ['index.html', 'assets/css/style.css', 'assets/js/main.js', 'assets/img/favicon.svg', 'build-docs.js'];
for (const f of files) {
  const c = fs.readFileSync(path.join(ROOT, f), 'utf8');
  const lines = c.split(/\r?\n/);
  let bad = 0;
  lines.forEach((ln, i) => {
    const m = ln.match(new RegExp('[^' + ALLOWED.source.slice(1, -1) + ']', 'g'));
    if (m) { err(f + ':' + (i + 1) + ' karakter asing ' + JSON.stringify(m.join(''))); bad++; }
  });
  if (!bad) ok(f);
}

console.log('\n=== 4. Cek struktur HTML ===');
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
const dup = ids.filter((v, i) => ids.indexOf(v) !== i);
dup.length ? err('ID duplikat: ' + [...new Set(dup)].join(', ')) : ok('tidak ada id duplikat (' + ids.length + ' id)');

const anchors = [...html.matchAll(/href="#([^"]+)"/g)].map((m) => m[1]);
const missing = anchors.filter((a) => !ids.includes(a));
missing.length ? err('anchor tanpa target: ' + missing.join(', ')) : ok('semua anchor punya target');

const arIA = (html.match(/\bfor=/g) || []).length;
console.log('  info: atribut for (label) = ' + arIA);

['navToggle', 'navMenu', 'navbar', 'sopGrid', 'sopFilters', 'sopSearch', 'sopCount', 'sopEmpty', 'toTop', 'year']
  .forEach((id) => (ids.includes(id) ? ok('id#' + id) : err('id#' + id + ' tidak ada di HTML tapi dipakai JS')));

console.log('\n=== 5. Cek konten SOP ===');
const sopNos = [...js.matchAll(/no:\s*'([^']+)'/g)].map((m) => m[1]);
console.log('  jumlah entri SOP di JS: ' + sopNos.length);
const dupSop = sopNos.filter((v, i) => sopNos.indexOf(v) !== i);
dupSop.length ? err('nomor SOP duplikat: ' + dupSop.join(', ')) : ok('nomor SOP unik');

const dataCats = [...new Set([...js.matchAll(/category:\s*'([^']+)'/g)].map((m) => m[1]))];
console.log('  kategori: ' + dataCats.join(', '));
const sopLinksInHtml = (html.match(/docs\//g) || []).length;
sopLinksInHtml ? warn('ada ' + sopLinksInHtml + ' path docs/ hardcoded di HTML (sebaiknya lewat JS)') : ok('tidak ada path docs/ hardcoded di HTML');

console.log('\n=== 6. Cek link eksternal ===');
const ext = [...html.matchAll(/https?:\/\/[^"'\s)]+/g)].map((m) => m[0]);
console.log('  link eksternal: ' + (ext.length ? ext.join(', ') : 'tidak ada (fully offline)'));

console.log('\n=========================================');
console.log(errors ? errors + ' ERROR, ' + warns + ' warning' : 'SEMUA LULUS' + (warns ? ' (' + warns + ' warning)' : ''));
console.log('=========================================\n');
process.exit(errors ? 1 : 0);
