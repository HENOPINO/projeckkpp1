const fs = require('fs');
const path = require('path');

const OUT = path.join(__dirname, 'docs');
fs.mkdirSync(OUT, { recursive: true });

const DOCS = [
  ['SOP-OB-001-Stripping-Overburden.pdf', 'SOP-OB-001', 'Pelaksanaan Stripping Overburden', 'Overburden', '03', '12 Januari 2026'],
  ['SOP-OB-004-Penanganan-Material.pdf', 'SOP-OB-004', 'Penanganan Material ke Stockpile', 'Overburden', '02', '04 Februari 2026'],
  ['SOP-PRD-002-Pengeboran-Sampel.pdf', 'SOP-PRD-002', 'Pengeboran dan Pengambilan Sampel', 'Produksi', '05', '20 Februari 2026'],
  ['SOP-PRD-006-Loading-Belt-Conveyor.pdf', 'SOP-PRD-006', 'Pengangkutan Batubara ke Belt Conveyor', 'Produksi', '01', '02 Maret 2026'],
  ['SOP-K3-001-Keselamatan-Kerja.pdf', 'SOP-K3-001', 'Keselamatan Kerja di Area Tambang', 'K3', '07', '18 Maret 2026'],
  ['SOP-K3-005-Toolbox-Meeting.pdf', 'SOP-K3-005', 'Pelaksanaan Toolbox Meeting', 'K3', '02', '25 Maret 2026'],
  ['SOP-MT-003-Preventive-Maintenance.pdf', 'SOP-MT-003', 'Preventive Maintenance Alat Berat', 'Alat Berat', '04', '08 April 2026'],
  ['SOP-MT-008-Troubleshooting-Alat.pdf', 'SOP-MT-008', 'Penanganan Kerusakan Alat di Lapangan', 'Alat Berat', '01', '15 April 2026'],
];

const esc = (s) => s.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

function buildPdf(lines) {
  let content = 'BT\n/F1 20 Tf\n1 0 0 1 62 742 Tm\n(DEPARTEMEN SUPPORT TAMBANG BATUBARA - PT KPP) Tj\nET\n';
  content += '0.35 w\n62 730 m 550 730 l S\n';
  let y = 700;
  for (const line of lines) {
    const [size, font] = line.bold ? [12, '/F2'] : [11, '/F1'];
    content += `BT\n${font} ${size} Tf\n1 0 0 1 62 ${y} Tm\n0.13 0.13 0.13 rg\n(${esc(line.text)}) Tj\nET\n`;
    y -= line.gap || 22;
  }
  content += `BT\n/F1 9 Tf\n0.45 0.45 0.45 rg\n1 0 0 1 62 60 Tm\n(Dokumen placeholder - ganti dengan SOP resmi PT KPP sebelum dipublikasikan.) Tj\nET\n`;

  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>',
    `<< /Length ${content.length} >>\nstream\n${content}endstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
  ];

  let pdf = '%PDF-1.4\n';
  const offsets = [];
  objs.forEach((body, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });

  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (const off of offsets) pdf += `${String(off).padStart(10, '0')} 00000 n \n`;
  pdf += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;

  return Buffer.from(pdf, 'latin1');
}

let count = 0;
for (const [filename, no, title, category, rev, date] of DOCS) {
  const lines = [
    { text: `No. Dokumen  : ${no}`, bold: true, gap: 30 },
    { text: `Judul       : ${title}` },
    { text: `Kategori    : ${category}` },
    { text: `Revisi      : ${rev}`, bold: true },
    { text: `Tanggal     : ${date}` },
    { text: ``, gap: 26 },
    { text: `1. Tujuan`, bold: true, gap: 24 },
    { text: `Menjadi acuan kerja personel Departemen Support Tambang dalam` },
    { text: `melaksanakan aktivitas sesuai prosedur yang berlaku.` },
    { text: ``, gap: 20 },
    { text: `2. Ruang Lingkup`, bold: true, gap: 24 },
    { text: `Berlaku untuk seluruh personel yang terlibat pada pekerjaan` },
    { text: `di area tambang Unit / Departemen Support Tambang PT KPP.` },
    { text: ``, gap: 20 },
    { text: `3. Dokumen Pendukung`, bold: true, gap: 24 },
    { text: `- SOP Keselamatan Kerja (K3 Umum)` },
    { text: `- SOP Preventive Maintenance Alat Berat` },
    { text: `- Izin Kerja / Work Permit area terkait` },
    { text: ``, gap: 20 },
    { text: `Catatan: dokumen ini hanya contoh untuk kebutuhan layout website.`, gap: 24 },
    { text: `Ganti dengan SOP resmi yang berlaku di PT KPP sebelum dipublikasikan.` },
  ];

  const target = path.join(OUT, filename);
  fs.writeFileSync(target, buildPdf(lines));
  count++;
  console.log('  created', filename);
}

console.log(`\n${count} PDF dibuat di ${OUT}`);
